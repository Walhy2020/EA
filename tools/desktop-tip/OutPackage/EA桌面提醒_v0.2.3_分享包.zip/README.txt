EA 桌面提醒
版本：0.2.3

这个目录用于放分享给同事的输出包。
打包时应包含：
- desktop-tip-client.ps1
- 启动EA右下角提醒.bat
- config\desktop-tip-client.config.json
- README.md

同事第一次启动无需登录，也无需填写企业微信 UserID；客户端会自动生成并保存唯一 clientId。
分享包默认连接：https://com.veryeazy.com:39200
成功启动并连接 EA 一次后，服务端才会把这台客户端安装实例记录为已登记桌面客户端。
只复制文件但从未启动、或从未成功连上 EA 的客户端，服务端无法知道，不会收到本次全员桌面提醒。
正式服停服更新通知会显示独立面板：倒计时、已停服、已延长、已完成状态会直接显示。
